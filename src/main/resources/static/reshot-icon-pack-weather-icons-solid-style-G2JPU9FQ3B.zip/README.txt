This "Weather Icons - Solid Style" icon pack was downloaded from https://www.reshot.com/free-svg-icons/pack/weather-icons-solid-style-G2JPU9FQ3B/ 

Please check the Reshot Icons license available at https://www.reshot.com/license/